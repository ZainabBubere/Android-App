package com.example.new_app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class subscription extends Fragment {
    Button sub;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.subscription_fragment, container, false);
        sub = view.findViewById(R.id.sub);

        SharedPreferences pref = getContext().getSharedPreferences("My Pref", Context.MODE_PRIVATE);
        boolean subvalue = pref.getBoolean("subs",false);

        if(subvalue) sub.setText("Subscribed");
        else sub.setText("Subscribe");

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SubsDialog subsDialog = new SubsDialog();
                subsDialog.show(getFragmentManager(),null);
            }
        });
        return view;
    }
}

