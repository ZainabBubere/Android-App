package com.example.new_app;

public class Library_list {
    private int videoimg;
    private String gname;
    private String gcomp;
    private String gdate;

    public Library_list(int videoimg, String gname, String gcomp, String gdate){
        this.videoimg = videoimg;
        this.gname = gname;
        this.gcomp = gcomp;
        this.gdate = gdate;
    }

    public int getVideoimg() {
        return videoimg;
    }

    public void setVideoimg(int videoimg) {
        this.videoimg = videoimg;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGcomp() {
        return gcomp;
    }

    public void setGcomp(String gcomp) {
        this.gcomp = gcomp;
    }

    public String getGdate() {
        return gdate;
    }

    public void setGdate(String gdate) {
        this.gdate = gdate;
    }
}

