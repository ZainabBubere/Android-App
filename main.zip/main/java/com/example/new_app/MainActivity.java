package com.example.new_app;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new home()).commit();
        bottomNavigationView = findViewById(R.id.bottom_nav_bar);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener(){
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragmentSelected = null;
                switch (item.getItemId()) {
                    case R.id.home:
                        fragmentSelected = new home();
                        break;

                    case R.id.explore:
                        fragmentSelected = new explore();
                        break;

                    case R.id.subscriptions:
                        fragmentSelected = new subscription();
                        break;

                    case R.id.inbox:
                        fragmentSelected = new inbox();
                        break;

                    case R.id.library:
                        fragmentSelected = new library();
                        break;

                }
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragmentSelected).commit();
                return true;



                };

            });
        }



        public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.options,menu);
        return true;
        }


}
