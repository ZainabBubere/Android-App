package com.example.new_app;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class SubsDialog extends DialogFragment {
    TextView sub;
    public Dialog onCreateDialog(@Nullable Bundle savedInstance) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog, null);
        sub = view.findViewById(R.id.dialog_text);
        SharedPreferences pref = getContext().getSharedPreferences("My Pref", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = pref.edit();
        final boolean subdernot = pref.getBoolean("subs",false);

        if (subdernot) sub.setText("    Do you want to unsubscribe? ");
        else  sub.setText("     Do you want to subscribe?");
        builder.setView(view)
                .setTitle("Confirm")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(subdernot){
                            editor.putBoolean("subs",false);
                            editor.apply();
                            Button button = getActivity().findViewById(R.id.sub);
                            button.setText("Subscribe");
                        }
                        else {
                            editor.putBoolean("subs",true);
                            editor.apply();
                            Button button = getActivity().findViewById(R.id.sub);
                            button.setText("Subscribed");
                        }

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        return builder.create();

    }
}
