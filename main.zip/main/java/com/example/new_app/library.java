package com.example.new_app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class library extends Fragment {
    RecyclerView recyclerView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.library_fragment, container,false);
        recyclerView = view.findViewById(R.id.library_recycler);

        List<Library_list> library_lists = new ArrayList<>();
        library_lists.add(new Library_list(R.drawable.mario,"Super Mario", "Nintendo", "Played 33 mins ago"));
        library_lists.add(new Library_list(R.drawable.minecraft,"MineCraft", "Mojang Studios", "Played 2 hrs ago"));
        library_lists.add(new Library_list(R.drawable.pubg,"PUBG", "Tencent Games", "Played 2 days ago"));
        library_lists.add(new Library_list(R.drawable.angrybirds,"Angry Birds", "Rovio Entertainment", "Played a day ago"));
        library_lists.add(new Library_list(R.drawable.bingo,"Bingo", "Absolute Games", "Played 3 days ago"));
        library_lists.add(new Library_list(R.drawable.cod,"Call of Duty", "Activision Publishing", "Played a day ago"));
        library_lists.add(new Library_list(R.drawable.play,"Video Game", "Xbox", "Installed 28 June"));
        library_lists.add(new Library_list(R.drawable.png,"Bomber", "46/63 Achievements", "Played 33 mins ago"));
        library_lists.add(new Library_list(R.drawable.oyuncu,"Oyuncu", "Li Kon", "Played a day ago"));


        LibraryAdapter adapter = new LibraryAdapter(library_lists);
        recyclerView.setAdapter(adapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

        return view;
    }
}
