package com.example.new_app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class home extends Fragment {
    RecyclerView recyclerView;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.home_fragment, container,false);
        recyclerView=view.findViewById(R.id.home_recycler);

        List<Video_list> video_lists= new ArrayList<>();
        video_lists.add(new Video_list(R.drawable.png,"Hello"));
        video_lists.add(new Video_list(R.drawable.mario,"Hi"));
        video_lists.add(new Video_list(R.drawable.minecraft,"How are you?"));
        video_lists.add(new Video_list(R.drawable.pubg,"What to do next?"));
        video_lists.add(new Video_list(R.drawable.oyuncu,"Lets see"));
        
        HomeAdapter adapter=new HomeAdapter(video_lists);
        recyclerView.setAdapter(adapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);


        return view;
    }
}
