package com.example.new_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LibraryAdapter extends RecyclerView.Adapter<LibraryAdapter.ViewHolder> {

    public List<Library_list> library_lists;

    public LibraryAdapter(List<Library_list> library_lists) {
        this.library_lists = library_lists;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_library, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LibraryAdapter.ViewHolder holder, int position) {
        holder.videoimg.setImageResource(library_lists.get(position).getVideoimg());
        holder.gname.setText(library_lists.get(position).getGname());
        holder.gcomp.setText(library_lists.get(position).getGcomp());
        holder.gdate.setText(library_lists.get(position).getGdate());

    }

    @Override
    public int getItemCount() {
        return library_lists.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView videoimg;
        private TextView gname;
        private TextView gcomp;
        private TextView gdate;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            videoimg = itemView.findViewById(R.id.videoimg);
            gname = itemView.findViewById(R.id.gname);
            gcomp = itemView.findViewById(R.id.gcomp);
            gdate = itemView.findViewById(R.id.gdate);
        }
    }
}
